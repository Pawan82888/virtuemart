#About VirtueMart module
This Cloudbanking module for VirtueMart allows owners of VirtueMart-powered stores to integrate PCloudbanking-payment-pligin with a few clicks and accept payments from all over the world via credit cards.

###Versions
Tested on VirtueMart 3.2.2 and Joomla! 3.7.5 Stable 

#Installation
To install cloudbanking VirtueMart module, please follow the [instructions]

1.Go to VirtueMart Extension Manager (http://[path-to-virtuemart] /administrator/index.php?option=com_installer).

2.In the VirtueMart Extension Manager, choose the .zip file you downloaded and press Upload and Install.

3.Go to VirtueMart payments settings (http://[path-to-virtuemart]/administrator/index.php?option=com_virtuemart&view=paymentmethod).

4.Press the New button.

5.fill all given fields.

6.Press the Save button to save the changes.

7.Next, switch to Configuration tab and fill out all the fields.

8.Press Save & Close to save the changes.

